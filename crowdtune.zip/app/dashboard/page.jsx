import { createClient } from '@/lib/supabase/server';

export default async function DashboardPage() {
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();

    return(
        <div>
            <h1>Dashboard</h1>
            <p>Welcome, {user.email}!</p>
        </div>
    )

}